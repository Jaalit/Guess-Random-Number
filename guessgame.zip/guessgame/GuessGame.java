
package guessgame;
import java.util.Scanner;

public class GuessGame {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int random = (int)(Math.random()*100);
        System.out.println("Welcome to the Random Number Guess Game");
        System.out.print("Please enter a number for guess the random number: ");
        int guess = sc.nextInt();
        while(guess != random){
            if (guess<random) {
                System.out.println("Your guess is wrong but less than the random number.");
                System.out.print(" Please try again: ");
                guess = sc.nextInt();
            }else if(guess>random){
                System.out.println("Your guess is wrong but higher than the random number.");
                System.out.print(" Please try again: ");
                guess = sc.nextInt();
            }
            
        }
        System.out.println("Your guess is right. The random number was " + random);
    }
    
}
